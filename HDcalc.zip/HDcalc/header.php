
<!DOCTYPE html>
<html class="no-js" lang="en-US" prefix="og: http://ogp.me/ns#">
<head>
	
	<link  rel="icon" type="" href="">
</head>
<body>
	<header>
		<a href="narcissi-home.php id="logo"><img /></a>
		<nav>
			<a href="narcissi-home.php" id="menu-icon"></a>
			<ul>
				<li><a href="narcissi-home.html" class="current">Home</a></li>
				<li><a href="narcissi-mainboard.html">Mainboard</a></li>
				<li><a href="narcissi-Newfaces.html">Newfaces</a></li>
				<li><a href="narcissi-Submission.html">Submission</a></li>
			</ul>
		</nav>
	</header>
</body>
</html>
